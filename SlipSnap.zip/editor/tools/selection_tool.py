from .base_tool import BaseTool


class SelectionTool(BaseTool):
    """Tool that relies on built-in selection of the scene."""
    pass
